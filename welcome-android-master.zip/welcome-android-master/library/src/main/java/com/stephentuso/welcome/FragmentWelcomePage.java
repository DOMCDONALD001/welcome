package com.stephentuso.welcome;

//This really only exists to get rid of the generic for clients
/**
 *
 * Created by stephentuso on 10/11/16.
 */
public abstract class FragmentWelcomePage extends WelcomePage<FragmentWelcomePage> {

}
