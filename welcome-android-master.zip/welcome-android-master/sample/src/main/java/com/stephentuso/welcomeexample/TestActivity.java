package com.stephentuso.welcomeexample;

import android.support.v7.app.AppCompatActivity;

/**
 * Blank activity used by instrumented tests
 * Created by stephentuso on 10/9/16.
 */
public class TestActivity extends AppCompatActivity {



}
